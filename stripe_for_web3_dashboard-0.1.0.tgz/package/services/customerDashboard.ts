// services/customerDashboard.ts

import { createSupabaseClient } from "@/utils/supabase/client";

import type { Merchant, Customer, Subscription } from "@/types/dashboard";

// import protocolAbi from "@/abi/Web3BillingProtocol.json";

import {
  createPublicClient,
  erc20Abi,
  formatUnits,
  getContract,
  type Address,
  type PublicClient,
  type WalletClient,
  http,
} from "viem";

/* -------------------------------------------------------------------------- */
/* Current Customer                                                            */
/* -------------------------------------------------------------------------- */

const supabase = createSupabaseClient();

export async function getCurrentCustomer(
  wallet: `0x${string}`,
): Promise<Customer | null> {
  const { data, error } = await supabase

    .from("customers")

    .select("*")

    .eq("wallet_address", wallet)

    .maybeSingle();

  if (error) throw error;

  if (!data) return null;

  return {
    customerId: data.customer_id,

    displayName: data.display_name,

    email: data.email,

    walletAddress: data.wallet_address,

    smartAccount: data.smart_account,

    status: data.status,

    createdAt: data.created_at,

    updatedAt: data.updated_at,
  };
}

/* -------------------------------------------------------------------------- */
/* Featured Merchants                                                          */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* Featured Merchants                                                         */
/* -------------------------------------------------------------------------- */

export async function getFeaturedMerchants(): Promise<Merchant[]> {
  const response = await fetch("/api/merchant/featured", {
    method: "GET",
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error("Unable to load featured merchants.");
  }

  const data = await response.json();

  console.log("merchant data received:", data);

  return (data ?? []).map((merchant: any) => ({
    merchantId: merchant.merchant_id,

    smartAccount: merchant.smart_account,

    payoutWallet: merchant.payout_wallet,

    ownerWallet: merchant.owner_wallet,

    name: merchant.name,

    metadataURI: merchant.metadata_uri,

    status: merchant.status,

    createdAt: merchant.created_at,

    updatedAt: merchant.updated_at,
  }));
}

/* -------------------------------------------------------------------------- */
/* Active Subscriptions                                                        */
/* -------------------------------------------------------------------------- */

export async function getActiveSubscriptions(
  customerId: string,
): Promise<Subscription[]> {
  console.log("customerId: ", customerId);

  const response = await fetch(
    `/api/customers/${customerId}/subscriptions`,

    {
      cache: "no-store",
    },
  );

  if (!response.ok) {
    throw new Error("Unable to fetch active subscriptions.");
  }

  return await response.json();
}

/* -------------------------------------------------------------------------- */
/* Blockchain                                                                  */
/* -------------------------------------------------------------------------- */

import type { BillingPlan } from "@/types/dashboard";

/* -------------------------------------------------------------------------- */
/* Wallet Balance                                                              */
/* -------------------------------------------------------------------------- */

export interface WalletBalance {
  token: `0x${string}`;

  symbol: string;

  decimals: number;

  raw: bigint;

  formatted: string;
}

export async function getWalletBalance(
  wallet: `0x${string}`,

  token: `0x${string}`,

  publicClient?: PublicClient,
): Promise<WalletBalance> {
  const client =
    publicClient ??
    createPublicClient({
      chain,

      transport: http(),
    });

  const contract = getContract({
    address: token,

    abi: erc20Abi,

    client,
  });

  console

  const [raw, decimals, symbol] = await Promise.all([
    contract.read.balanceOf([wallet]),

    contract.read.decimals(),

    contract.read.symbol(),
  ]);

  return {
    token,

    symbol,

    decimals,

    raw,

    formatted: formatContractBalance(formatUnits(raw, decimals)),
  };
}

const formatContractBalance = (balance: string): string => {
  if (!balance.includes(".")) return balance;

  const indexOfPoint = balance.indexOf(".");
  const indexOf2ndDecimalPlace = indexOfPoint + 2;

  return balance.slice(0, indexOf2ndDecimalPlace);
};

/* -------------------------------------------------------------------------- */
/* Wallet Balances For Every Active Plan Token                                */
/* -------------------------------------------------------------------------- */

export async function getWalletBalances(
  wallet: `0x${string}`,

  plans: BillingPlan[],

  publicClient?: PublicClient,
): Promise<WalletBalance[]> {
  const uniqueTokens = [...new Set(plans.map((plan) => plan.paymentToken))];

  return Promise.all(
    uniqueTokens.map((token) =>
      getWalletBalance(
        wallet,

        token,

        publicClient,
      ),
    ),
  );
}

/* -------------------------------------------------------------------------- */
/* Merchant Plans                                                              */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* Merchant Plans                                                              */
/* -------------------------------------------------------------------------- */

export async function getMerchantPlans(
  merchantId: number,
): Promise<BillingPlan[]> {
  const response = await fetch(
    `/api/merchant/${merchantId}/plans`,

    {
      cache: "no-store",
    },
  );

  if (!response.ok) {
    throw new Error("Unable to load merchant plans.");
  }

  return await response.json();
}

/* -------------------------------------------------------------------------- */
/* Balance Check                                                               */
/* -------------------------------------------------------------------------- */

export async function hasEnoughBalance(
  wallet: `0x${string}`,

  plan: BillingPlan,

  publicClient?: PublicClient,
): Promise<boolean> {
  console.log("plan =", plan);
  console.log("wallet =", wallet);
  console.log("payment token =", plan.paymentToken);

  const balance = await getWalletBalance(
    wallet,

    plan.paymentToken,

    publicClient,
  );

  return balance.raw >= BigInt(plan.amount);
}

import { getCustomerKernel } from "@/services/customer";
import { getMerchantById } from "@/services/merchant";
import { mirrorSubscription } from "@/services/subscription";
import { approveTokenIfNeeded } from "@/services/token";
import { subscribeToBillingPlan } from "@/services/billingProtocol";
import { chain } from "./kernel.client";


import Web3BillingProtocolABI from "@/abi/Web3BillingProtocol.json";

const BILLING_CONTRACT = process.env
  .NEXT_PUBLIC_BILLING_CONTRACT_ADDRESS as `0x${string}`;

export async function hasActiveSubscription(
  publicClient: PublicClient,
  subscriber: `0x${string}`,
  planId: bigint,
) {
  const subscriptionIds = (await publicClient.readContract({
    address: BILLING_CONTRACT,

    abi: Web3BillingProtocolABI,

    functionName: "getPlanSubscriptions",

    args: [planId],
  })) as bigint[];

  for (const subscriptionId of subscriptionIds) {
    const subscription = await publicClient.readContract({
      address: BILLING_CONTRACT,

      abi: Web3BillingProtocolABI,

      functionName: "getSubscription",

      args: [subscriptionId],
    }) as Subscription;

    if (
      subscription.subscriber!.toLowerCase() === subscriber.toLowerCase() &&
      subscription.status === "ACTIVE"
    ) {
      return true;
    }
  }
  return false;
}


export interface SubscribeParams {
  walletClient: WalletClient;

  publicClient: PublicClient;

  customerId: string;

  plan: BillingPlan;
}

export async function subscribe({
  walletClient,
  publicClient,
  customerId,
  plan,
}: SubscribeParams) {
  /*
    --------------------------------------------------------------------------
    Phase 1
    Validate Customer Balance
    --------------------------------------------------------------------------
    */
  console.log("Plan at subscribe: ", plan);

  const wallet = (await walletClient.getAddresses())[0];

  const enoughBalance = await hasEnoughBalance(wallet, plan, publicClient);

  if (!enoughBalance) {
    throw new Error("Insufficient token balance for recurring billing.");
  }

  /*
    --------------------------------------------------------------------------
    Phase 2
    Load Customer Context
    --------------------------------------------------------------------------
    */

  const {
    customer,

    kernel: customerKernel,

    kernelClient: customerKernelClient,

    permission,
  } = await getCustomerKernel(walletClient, publicClient);


  const alreadySubscribed =
      await hasActiveSubscription(

          publicClient,

          customer.smartAccount,

          BigInt(plan.planId),

      );

  if (alreadySubscribed) {

      throw new Error(
          "You already have an active subscription to this plan."
      );

  }

  console.log("permission: ", permission);

  if (!customer.smartAccount) {
    throw new Error("Customer Smart Account is missing.");
  }

  console.log("customerKernel retrieved...");

  /*
    --------------------------------------------------------------------------
    Phase 3
    Load Merchant
    --------------------------------------------------------------------------
    */

  const merchant = await getMerchantById(BigInt(plan.merchantId));

  if (!merchant) {
    throw new Error("Merchant not found.");
  }

  /*
    --------------------------------------------------------------------------
    Optional Merchant Validation
    --------------------------------------------------------------------------
    */

  if (merchant.status !== "ACTIVE") {
    throw new Error("Merchant is inactive.");
  }

  /*
    --------------------------------------------------------------------------
    Phase 4
    Approve ERC20
    --------------------------------------------------------------------------
    */

  await approveTokenIfNeeded({
    walletClient,

    publicClient,

    owner: customer.smartAccount,

    spender: process.env.NEXT_PUBLIC_BILLING_CONTRACT_ADDRESS as `0x${string}`,

    token: plan.paymentToken,

    amount: BigInt(plan.amount),
  });

  /*
    --------------------------------------------------------------------------
    Phase 5
    Subscribe On-Chain
    --------------------------------------------------------------------------
    */

  const {
    userOperationHash,

    receipt,

    subscriptionId,
  } = await subscribeToBillingPlan({
    kernel: customerKernel,

    kernelClient: customerKernelClient,

    planId: BigInt(plan.planId),

    smartAccount: customer.smartAccount,

    permissionId: permission.permissionId,

    publicClient: publicClient,
  });

  /*
    --------------------------------------------------------------------------
    Phase 6
    Mirror Into Supabase
    --------------------------------------------------------------------------
    */

  const subscription = await mirrorSubscription({
    subscriptionId: Number(subscriptionId),

    customerId,

    merchantId: plan.merchantId,

    planBillingIntervalSeconds: plan.billingIntervalSeconds,

    planId: plan.planId,

    smartAccount: customer.smartAccount,

    transactionHash: userOperationHash,

    permissionId: permission.permissionId,
  });

  /*
    --------------------------------------------------------------------------
    Done
    --------------------------------------------------------------------------
    */

  return {
    merchant,

    customer,

    subscription,

    receipt,

    transactionHash: userOperationHash,
  };
}
